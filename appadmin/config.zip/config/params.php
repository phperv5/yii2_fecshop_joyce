<?php

return [
    /*
     * admin language for  attribute
     */

    'systemlog' => [
        'enable' => 1,
    ],
    'localThemeDir' => '@appadmin/theme/local/theme01',
];
